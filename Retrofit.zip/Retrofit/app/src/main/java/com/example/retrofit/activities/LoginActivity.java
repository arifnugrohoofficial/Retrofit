package com.example.retrofit.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.retrofit.R;
import com.example.retrofit.models.LoginResponse;
import com.example.retrofit.models.RetrofitClient;
import com.example.retrofit.storage.SharedPrefeManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{



private EditText editText_Email;
private EditText editText_Password;
private ProgressDialog loadingBar;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editText_Email = findViewById(R.id.edit_textEmail);
        editText_Password = findViewById(R.id.edit_textPassword);
        loadingBar = new ProgressDialog(this);


        findViewById(R.id.button_Login).setOnClickListener(this);
        findViewById(R.id.text_viewRegister).setOnClickListener(this);




    }

    @Override
    protected void onStart() {
        super.onStart();
        if(SharedPrefeManager.getInstance(this).isLoggedIn()){
            Intent intent = new Intent(this,Profile.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);

        }
    }

    private void userLogin(){

        String email = editText_Email.getText().toString().trim();
        String password = editText_Password.getText().toString().trim();

        if (email.isEmpty()){

            editText_Email.setError("Email is required");
            editText_Email.requestFocus();
            return;

        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            editText_Email.setError("Masukan Email yang valid");
            editText_Email.requestFocus();
            return;

        }


        if (password.isEmpty()) {

            editText_Password.setError("Password is required");
            editText_Password.requestFocus();
            return;


        }

        if (password.length() < 6){

            editText_Password.setError("password kurang lebih harus 6 karakter");
            editText_Password.requestFocus();
            return;


        }
        else
        {
            loadingBar.setTitle("Login Akun");
            loadingBar.setMessage("nunggu ya bro");
            loadingBar.setCanceledOnTouchOutside(false);
            loadingBar.show();




        }
        Call<LoginResponse> call = RetrofitClient
                .getInstance().getApi().userLogin(email, password);

         call.enqueue(new Callback<LoginResponse>() {
             @Override
             public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                 LoginResponse loginResponse = response.body();

                 if(!loginResponse.isError()){


                     SharedPrefeManager.getInstance(LoginActivity.this)
                             .saveUser(loginResponse.getUser());

                     Intent intent = new Intent(LoginActivity.this,Profile.class);
                     intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                     startActivity(intent);




                 }else{
                     Toast.makeText(LoginActivity.this, loginResponse.getMessage(), Toast.LENGTH_LONG).show();
                 }

             }

             @Override
             public void onFailure(Call<LoginResponse> call, Throwable t) {

             }
         });


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.button_Login:
                userLogin();
                break;

            case R.id.text_viewRegister:
                startActivity(new Intent(this, MainActivity.class));
                break;



        }

    }
}
