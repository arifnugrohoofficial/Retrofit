package com.example.retrofit.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.retrofit.api.DefaultResponse;
import com.example.retrofit.R;
import com.example.retrofit.models.RetrofitClient;
import com.example.retrofit.storage.SharedPrefeManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    private EditText editTextEmail, editTextPassword, editTextName, editTextSchool;
    private ProgressDialog loadingBar;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextEmail =findViewById(R.id.edit_textEmail);
        editTextPassword = findViewById(R.id.edit_textPassword);
        editTextName = findViewById(R.id.edit_textName);
        editTextSchool = findViewById(R.id.edit_textSchool);
        loadingBar = new ProgressDialog(this);


        findViewById(R.id.button_signup).setOnClickListener(this);
        findViewById(R.id.text_viewLogin).setOnClickListener(this);

    }
    @Override
    protected void onStart() {
        super.onStart();
        if (SharedPrefeManager.getInstance(this).isLoggedIn()) {
            Intent intent = new Intent(this, Profile.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);

        }
    }

    private void userSignUp(){

        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String name = editTextName.getText().toString().trim();
        String school = editTextSchool.getText().toString().trim();

        if (email.isEmpty()){

            editTextEmail.setError("Email is required");
            editTextEmail.requestFocus();
            return;

        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            editTextEmail.setError("Masukan Email yang valid");
            editTextEmail.requestFocus();
            return;

        }


        if (password.isEmpty()) {

            editTextPassword.setError("Password is required");
            editTextPassword.requestFocus();
            return;


        }

        if (password.length() < 6){

            editTextPassword.setError("password kurang lebih harus 6 karakter");
            editTextPassword.requestFocus();
            return;


        }

        if (name.isEmpty()) {

            editTextName.setError("Name is required");
            editTextName.requestFocus();
            return;
        }

        if (school.isEmpty()) {

            editTextSchool.setError("School is required");
            editTextSchool.requestFocus();
            return;


        }
        else
        {
            loadingBar.setTitle("Daptar Akun");
            loadingBar.setMessage("nunggu ya bro");
           loadingBar.setCanceledOnTouchOutside(false);
           loadingBar.getWindow();
            loadingBar.show();


        }
/* user melakukan pendaftaran menggunakan panggilan api */
        Call<DefaultResponse> call = RetrofitClient
                .getInstance()
                .getApi()
                .createUser(email, password, name, school);

 call.enqueue(new Callback<DefaultResponse>() {
     @Override
     public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {

         if(response.code() == 201){

             DefaultResponse dr = response.body();
             Toast.makeText(MainActivity.this, dr.getMsg(), Toast.LENGTH_LONG).show();
             Intent intent = new Intent(MainActivity.this,LoginActivity.class);
             intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
             startActivity(intent);


         }else if(response.code() == 422){
             Toast.makeText(MainActivity.this, "user sudah ada", Toast.LENGTH_LONG).show();



         }

     }

     @Override
     public void onFailure(Call<DefaultResponse> call, Throwable t) {

     }
 });

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){


            case R.id.button_signup:
                userSignUp();
                break;
            case R.id.text_viewLogin:
                startActivity(new Intent(this, LoginActivity.class));
                break;
        }

    }
}
