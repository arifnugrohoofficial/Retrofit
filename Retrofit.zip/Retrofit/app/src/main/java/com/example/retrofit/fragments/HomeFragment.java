package com.example.retrofit.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.retrofit.R;
import com.example.retrofit.storage.SharedPrefeManager;

public class HomeFragment extends Fragment {

    private TextView textViewEmail,textViewName, textViewSchool;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.home_fragment, container, false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        textViewEmail = view.findViewById(R.id.textView_Email);
        textViewName = view.findViewById(R.id.textView_Name);
        textViewSchool = view.findViewById(R.id.textView_School);

        textViewEmail.setText(SharedPrefeManager.getInstance(getActivity()).getUser().getEmail());
        textViewName.setText(SharedPrefeManager.getInstance(getActivity()).getUser().getName());
        textViewSchool.setText(SharedPrefeManager.getInstance(getActivity()).getUser().getSchool());



    }
}
