package com.example.retrofit.fragments;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.FloatProperty;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.retrofit.R;
import com.example.retrofit.activities.LoginActivity;
import com.example.retrofit.activities.MainActivity;
import com.example.retrofit.activities.Profile;
import com.example.retrofit.api.DefaultResponse;
import com.example.retrofit.models.LoginResponse;
import com.example.retrofit.models.RetrofitClient;
import com.example.retrofit.models.User;
import com.example.retrofit.storage.SharedPrefeManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SettingsFragment extends Fragment implements View.OnClickListener {


    private EditText editTextEmail1, editTextName1, editTextSchool1;
    private EditText editTextCurrentPassword1, editTextNewPassword1;
    private ProgressDialog loadingBar;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.settings_fragment, container, false);

         }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);




        editTextEmail1 = view.findViewById(R.id.edit_textEmail);
        editTextName1 = view.findViewById(R.id.edit_textName);
        editTextSchool1 = view.findViewById(R.id.edit_textSchool);
        editTextCurrentPassword1 = view.findViewById(R.id.editTextcurrentpassword1);
        editTextNewPassword1 = view.findViewById(R.id.editTextnewpassword1);


        view.findViewById(R.id.button_save).setOnClickListener(this);
        view.findViewById(R.id.button_changepassword).setOnClickListener(this);
        view.findViewById(R.id.button_logout).setOnClickListener(this);
        view.findViewById(R.id.button_delete).setOnClickListener(this);




    }

    private void updateProfile(){
        String email = editTextEmail1.getText().toString().trim();
        String name = editTextName1.getText().toString().trim();
        String school = editTextSchool1.getText().toString().trim();


        if (email.isEmpty()){
            editTextEmail1.setError("Email is required");
            editTextEmail1.requestFocus();
            return;

        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            editTextEmail1.setError("Masukan Email yang valid");
            editTextEmail1.requestFocus();
            return;

        }


        if (name.isEmpty()) {
            editTextName1.setError("Name is required");
            editTextName1.requestFocus();
            return;
        }


        if (school.isEmpty()) {
            editTextSchool1.setError("School is required");
            editTextSchool1.requestFocus();
            return;


        }

        User user = SharedPrefeManager.getInstance(getActivity()).getUser();


        Call<LoginResponse> call = RetrofitClient.getInstance()
                .getApi().updateUser(
                        user.getId(),
                        email,
                        name,
                        school



                );

call.enqueue(new Callback<LoginResponse>() {
    @Override
    public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {

       Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_LONG).show();

        if(!response.body().isError()){
            SharedPrefeManager.getInstance(getActivity()).saveUser(response.body().getUser());

        }

    }

    @Override
    public void onFailure(Call<LoginResponse> call, Throwable t) {



    }
});



    }

    private void updatePassword(){
        String currentpassword = editTextCurrentPassword1.getText().toString().trim();
        String newpassword = editTextNewPassword1.getText().toString().trim();

        if(currentpassword.isEmpty()){
            editTextCurrentPassword1.setError("password requirer");
            editTextCurrentPassword1.requestFocus();
            return;
        }
        if(newpassword.isEmpty()){
            editTextNewPassword1.setError("Enter New Password");
            editTextNewPassword1.requestFocus();
            return;
        }



        User user = SharedPrefeManager.getInstance(getActivity()).getUser();
        Call<DefaultResponse> call = RetrofitClient.getInstance().getApi()
                .updatePassword(currentpassword, newpassword, user.getEmail());

        call.enqueue(new Callback<DefaultResponse>() {
            @Override
            public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {




                Toast.makeText(getActivity(), response.body().getMsg(), Toast.LENGTH_LONG).show();

            }

            @Override
            public void onFailure(Call<DefaultResponse> call, Throwable t) {

            }
        });



    }

    private void logout(){



        SharedPrefeManager.getInstance(getActivity()).clear();
        Intent intent = new Intent(getActivity(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);



    }


    private void deleteUser(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("apa kau yakin...?");
        builder.setMessage("aksi ini reversible");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                User user = SharedPrefeManager.getInstance(getActivity()).getUser();
                Call<DefaultResponse> call = RetrofitClient.getInstance().getApi().deleteUser(user.getId());

                call.enqueue(new Callback<DefaultResponse>() {
                    @Override
                    public void onResponse(Call<DefaultResponse> call, Response<DefaultResponse> response) {

                        if(!response.body().isErr()) {
                            SharedPrefeManager.getInstance(getActivity()).clear();
                            SharedPrefeManager.getInstance(getActivity()).clear();
                            Intent intent = new Intent(getActivity(), MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);

                        }
                        Toast.makeText(getActivity(),response.body().getMsg(), Toast.LENGTH_LONG).show();

                    }

                    @Override
                    public void onFailure(Call<DefaultResponse> call, Throwable t) {

                    }
                });

            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {


            }
        });


        AlertDialog ad = builder.create();
        ad.show();

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.button_save:
                updateProfile();
                break;
            case R.id.button_changepassword:
                updatePassword();
                break;
            case R.id.button_logout:
                logout();
                break;
            case R.id.button_delete:
                deleteUser();
                break;

        }

    }
}
